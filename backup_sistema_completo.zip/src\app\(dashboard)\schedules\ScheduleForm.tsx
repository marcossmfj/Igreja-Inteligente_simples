'use client'

import { useState, useMemo } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Plus } from 'lucide-react'
import { addSchedule } from './actions'

interface Skill {
  id: string
  name: string
}

interface Member {
  id: string
  name: string
  member_skills: { skill_id: string }[]
}

export function ScheduleForm({ 
  skills, 
  members, 
  defaultValues 
}: { 
  skills: Skill[], 
  members: Member[],
  defaultValues?: { event_name: string, date: string }
}) {
  const [open, setOpen] = useState(false)
  const [selectedSkill, setSelectedSkill] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  // Filtrar membros que possuem a skill selecionada
  const filteredMembers = useMemo(() => {
    if (!selectedSkill) return members
    return members.filter(member => 
      member.member_skills.some(ms => ms.skill_id === selectedSkill)
    )
  }, [selectedSkill, members])

  return (
    <Dialog open={open} onOpenChange={(val) => {
      setOpen(val)
      if (!val) setError(null)
    }}>
      {defaultValues ? (
        <Button 
          size="icon-sm" 
          variant="ghost" 
          onClick={() => setOpen(true)} 
          className="h-8 w-8 rounded-full bg-primary/10 text-primary hover:bg-primary/20"
        >
          <Plus className="h-4 w-4" />
        </Button>
      ) : (
        <DialogTrigger render={<Button />}>
          <Plus className="mr-2 h-4 w-4" /> Criar Escala
        </DialogTrigger>
      )}
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{defaultValues ? `Adicionar à escala: ${defaultValues.event_name}` : 'Nova Escala'}</DialogTitle>
          <DialogDescription>
            {defaultValues 
              ? `Adicionando membros para o dia ${new Date(defaultValues.date).toLocaleDateString('pt-BR', {timeZone: 'UTC'})}`
              : 'Selecione a função e o sistema mostrará apenas os membros qualificados.'}
          </DialogDescription>
        </DialogHeader>

        {error && (
          <div className="p-3 text-sm bg-destructive/10 text-destructive rounded-md border border-destructive/20 font-medium mb-4">
            {error}
          </div>
        )}

        <form action={async (formData) => {
          setLoading(true)
          setError(null)
          const result = await addSchedule(formData)
          setLoading(false)
          
          if (result?.error) {
            setError(result.error)
          } else {
            setOpen(false)
            setSelectedSkill('')
          }
        }} className="space-y-4">
          <div className={defaultValues ? "hidden" : "space-y-2"}>
            <Label htmlFor="event_name">Nome do Culto / Evento</Label>
            <Input 
              id="event_name" 
              name="event_name" 
              defaultValue={defaultValues?.event_name} 
              placeholder="Ex: Culto de Domingo" 
              required={!defaultValues} 
            />
          </div>
          <div className={defaultValues ? "hidden" : "space-y-2"}>
            <Label htmlFor="date">Data do Culto</Label>
            <Input 
              id="date" 
              name="date" 
              type="date" 
              defaultValue={defaultValues?.date} 
              required={!defaultValues} 
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="skill_id">Função Necessária (Skill)</Label>
            <select
              id="skill_id"
              name="skill_id"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              value={selectedSkill}
              onChange={(e) => setSelectedSkill(e.target.value)}
              required
            >
              <option value="">Selecione a função...</option>
              {skills.map((skill) => (
                <option key={skill.id} value={skill.id}>
                  {skill.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="member_id">Membro Escalado</Label>
            <select
              id="member_id"
              name="member_id"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              required
            >
              <option value="">
                {selectedSkill 
                  ? `${filteredMembers.length} membros qualificados encontrados` 
                  : "Selecione a função primeiro"}
              </option>
              {filteredMembers.map((member) => (
                <option key={member.id} value={member.id}>
                  {member.name}
                </option>
              ))}
            </select>
            {selectedSkill && filteredMembers.length === 0 && (
              <p className="text-xs text-destructive mt-1">
                Aviso: Nenhum membro possui esta habilidade cadastrada.
              </p>
            )}
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? 'Agendando...' : 'Agendar na Escala'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}
